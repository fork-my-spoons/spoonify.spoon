# Spotify

![screenshot](./screenshot.png)

Spotify status and song in the menu bar

